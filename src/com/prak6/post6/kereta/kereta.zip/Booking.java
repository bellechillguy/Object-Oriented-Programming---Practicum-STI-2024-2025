import java.time.LocalDateTime;

public class Booking {
    // private String bookingId;
    // private String customerName;
    // private Train train;
    // private LocalDateTime time;
    private String bookingId;
    private String customerName;
    private Train train;
    private LocalDateTime time;

    /*
     * Inner static class untuk menghasilkan ID booking unik
     * TODO:    Buatlah private static attribute counter bertipe int, dengan nilai awal 1000
     * TODO:    Buatlah method public static generate() yang mengembalikan String ID booking
     *          dengan format "BK" diikuti counter yang di-increment setiap kali method ini 
     *          dipanggil. (Contoh: "BK1001", "BK1002", dst.)
     */
    public static class BookingIdGenerator {
        private static int counter = 1000;

        public static String generate() {
            String stringID = String.format("BK%d", counter + 1);
            counter++;
            return stringID;
        }
        // TODO: lengkapi code di sini
    }

    /*
     * Konstruktor kelas Booking
     * TODO:    Lengkapi semua state awal dari object Booking
     *          customerName dan train diisi dari parameter konstruktor
     *          Gunakan BookingIdGenerator.generate() untuk mengisi bookingId
     *          Gunakan LocalDateTime.of(2025, 10, 17, 10, 0, 0); untuk mengisi time (Tinggal panggil LocalDateTime.of(2025, 10, 17, 10, 0, 0) saja!)
     */
    public Booking(String customerName, Train train) {
        this.customerName = customerName;
        this.train = train;
        this.bookingId = BookingIdGenerator.generate();
        this.time = LocalDateTime.of(2025, 10, 17, 10, 0, 0);
        // TODO: lengkapi code di sini
    }

    /*
     * Getter untuk bookingId
     * TODO:    Kembalikan String bookingId;
     */
    public String getBookingId() {
        return this.bookingId;
        // TODO: lengkapi code di sini
    }
    
    /*
     * Getter untuk train
     * TODO:    Kembalikan object Train train
     */
    public Train getTrain() {
        return this.train;
        // TODO: lengkapi code di sini
    }

    /*
     * Override method toString() untuk menampilkan informasi booking
     * Format: bookingId | customerName | trainName | time
     *         Untuk mendapatkan string time, cukup panggil time saja karena nanti outputnya string
     *         (Kenapa bisa gitu? karena LocalDateTime sudah punya override toString() sendiri 
     *          di dalam librarynya)
     * Contoh: BK1001 | Alice | Argo Parahyangan | 2024-06-01T10:15:30.123
     */
    @Override
    public String toString() {
        return String.format("%s | %s | %s | %s", this.bookingId, this.customerName, this.train.getName(), this.time);
        // TODO: lengkapi code di sini
    }
}
