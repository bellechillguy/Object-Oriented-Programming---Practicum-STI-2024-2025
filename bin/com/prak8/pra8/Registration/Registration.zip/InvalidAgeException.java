public class InvalidAgeException extends Exception {
    // TODO: Buat konstruktor yang menerima String message dan memanggil super(message).
    public InvalidAgeException(String message) {
        super(message);
    }
}
