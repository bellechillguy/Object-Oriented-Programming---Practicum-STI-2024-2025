/**
 * Type.java
 * Enumerasi tipe unsur untuk Pokenimons.
 */
public enum Type {
    FIRE, WATER, GRASS, ELECTRIC
}